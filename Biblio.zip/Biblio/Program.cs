﻿// Inclusion des bibliothèques nécessaires
using Biblio; // Bibliothèque personnalisée (hypothétique) qui contient les classes Livre, Utilisateur, etc.
using System.Data.Common; // Pour la gestion des connexions à une base de données (même si non utilisé ici)
using System.Diagnostics; // Pour le diagnostic et les journaux (non utilisé dans ce contexte)
using System.Runtime.CompilerServices; // Utilisé pour les informations sur les appels de méthodes (non utilisé ici)

var listeUtilisateurs = new List<IUtilisateur>(); // Liste des utilisateurs de la bibliothèque
var listeLivres = new List<Livre>(); // Liste des livres disponibles à la bibliothèque

// Fonction pour créer un nouveau livre et l'ajouter à la liste des livres
void creeLivre()
{
    // Demande les informations sur le livre à l'utilisateur
    Console.WriteLine("Entrez le titre du livre");
    string titre = Console.ReadLine();
    Console.WriteLine("Entrez l'auteur du livre");
    string auteur = Console.ReadLine();
    Console.WriteLine("Entrez l'isbn du livre");
    string isbn = Console.ReadLine();
    Console.WriteLine("Entrez l'année de sortie du livre");
    string annee = Console.ReadLine();

    try
    {
        // Crée un nouveau livre et l'ajoute à la liste des livres
        listeLivres.Add(new Livre(titre, auteur, int.Parse(annee), int.Parse(isbn)));
    }
    catch
    {
        // Gestion d'erreur si un problème survient lors de l'ajout du livre
        throw new Exception("Une erreur est survenue lors de l'enregistrement du livre");
    }
}

// Fonction pour créer un utilisateur standard
void creeUtilisateur()
{
    Console.WriteLine("Entrez le nom de l'utilisateur");
    string nom = Console.ReadLine();
    Console.WriteLine("Entrez le prenom de l'utilisateur ");
    string prenom = Console.ReadLine();

    // Ajoute l'utilisateur avec un identifiant unique basé sur la taille de la liste actuelle
    listeUtilisateurs.Add(new Utilisateur(nom, prenom, listeUtilisateurs.Count));
}

// Fonction pour créer un utilisateur premium (qui aurait potentiellement plus de privilèges)
void creeUtilisateurPremium()
{
    Console.WriteLine("Entrez le nom de l'utilisateur");
    string nom = Console.ReadLine();
    Console.WriteLine("Entrez le prenom de l'utilisateur ");
    string prenom = Console.ReadLine();

    // Ajoute un utilisateur premium avec un identifiant unique
    listeUtilisateurs.Add(new UtilisateurPremium(nom, prenom, listeUtilisateurs.Count));
}

// Fonction pour supprimer un livre de la liste
void supprimerlivre()
{
    Console.WriteLine("Choissisez le livre à supprimer");
    listerLivres(); // Affiche la liste des livres disponibles

    try
    {
        // Sélectionne un livre à partir de l'entrée de l'utilisateur
        int num = int.Parse(Console.ReadLine());
        var livre = listeLivres.OrderBy(livre => livre.Titre).Skip(num).First();

        // Vérifie si le livre est emprunté, sinon le supprime
        if (livre.EstEmprunter)
        {
            throw new Exception("Le livre est emprunté");
        }
        listeLivres.Remove(livre);
        Console.WriteLine("Le livre a bien été supprimé");
    }
    catch
    {
        // Gestion d'erreur en cas de problème lors de la suppression du livre
        throw new Exception("Entrez une valeur valide");
    }
}

// Fonction pour supprimer un utilisateur
void supprimerUtilisateur()
{
    Console.WriteLine("Choisissez un utilisateur");
    listerUtilisateurs(); // Affiche la liste des utilisateurs

    try
    {
        // Sélectionne un utilisateur à partir de l'entrée de l'utilisateur
        int num = int.Parse(Console.ReadLine());
        var utilisateur = listeUtilisateurs.OrderBy(util => util.Nom).ThenBy(util => util.Prenom).Skip(num).First();

        // Supprime l'utilisateur sélectionné
        listeUtilisateurs.Remove(utilisateur);
    }
    catch
    {
        // Gestion d'erreur en cas de problème lors de la suppression de l'utilisateur
        throw new Exception("Entrez une valeur valide");
    }
}

// Fonction pour afficher la liste des livres
void listerLivres()
{
    int cpt = 0;
    // Trie les livres par titre et les affiche avec leurs détails
    foreach (var livre in listeLivres.OrderBy(livre => livre.Titre))
    {
        Console.WriteLine($"{cpt}. {livre.Titre} par {livre.Auteur} sorti en {livre.AnneeDePublication}. ISBN:{livre.ISBN} est emprunté : {(livre.EstEmprunter ? "Oui" : "Non")}");
        cpt++;
    }
}

// Fonction pour afficher la liste des utilisateurs
void listerUtilisateurs()
{
    int cpt = 0;
    // Trie les utilisateurs par nom et prénom, puis les affiche
    foreach (var util in listeUtilisateurs.OrderBy(util => util.Nom).ThenBy(util => util.Prenom))
    {
        Console.WriteLine($"{cpt}. {util.Nom} {util.Prenom}");
        cpt++;
    }
}

// Menu d'options pour les utilisateurs : emprunter, rendre, ou voir les livres empruntés
void menuUtilisateur(IUtilisateur utilisateur)
{
    while (true)
    {
        Console.WriteLine("Appuyer sur une touche pour continuer");
        Console.ReadKey();
        Console.Clear();
        Console.WriteLine("""
        Choisissez une option : 
        1. Emprunter un livre
        2. Rendre un livre 
        3. Voir livres empruntés
        X. Quitter
        """);

        switch (Console.ReadLine())
        {
            case "1":
                Console.WriteLine("Choisissez le livre à emprunter");
                listerLivres();
                try
                {
                    int num = int.Parse(Console.ReadLine());
                    var livre = listeLivres.OrderBy(livre => livre.Titre).Skip(num).First();

                    // Vérifie si le livre est déjà emprunté
                    if (livre.EstEmprunter)
                    {
                        throw new Exception("Le livre est emprunté");
                    }
                    utilisateur.emprunter(livre); // L'utilisateur emprunte le livre
                    Console.WriteLine("Le livre a bien été emprunté");
                }
                catch (FormatException)
                {
                    throw new Exception("Entrez une valeur valide");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                break;

            case "2":
                Console.WriteLine("Choisissez le livre à rendre");
                utilisateur.listerLivres(); // Liste les livres empruntés par l'utilisateur
                try
                {
                    int num = int.Parse(Console.ReadLine());
                    var emprunt = utilisateur.Emprunts.OrderBy(emp => emp.Livre.Titre).Skip(num).First();

                    utilisateur.rendre(emprunt); // L'utilisateur rend le livre
                    Console.WriteLine("Le livre a bien été rendu");
                }
                catch
                {
                    throw new Exception("Entrez une valeur valide");
                }
                break;

            case "3":
                utilisateur.listerLivres(); // Liste les livres empruntés par l'utilisateur
                break;

            case "X":
                return; // Quitte le menu utilisateur
            default:
                Console.WriteLine("Entrez une option valide");
                break;
        }
    }
}

// Menu principal avec les options pour gérer livres et utilisateurs
while (true)
{
    Console.WriteLine("Appuyer sur une touche pour continuer");
    Console.ReadKey();
    Console.Clear();
    Console.WriteLine("""
        1. Ajouter un livre 
        2. Supprimer un livre 
        3. Ajouter un utilisateur
        4. Ajouter un utilisateur premium 
        5. Supprimer un utilisateur
        6. Lister les livres 
        7. Lister les utilisateurs 
        8. Choisir utilisateur pour emprunter/rendre/voir livres empruntés
        X. Quitter
        """);
    try
    {
        switch (Console.ReadLine())
        {
            case "1":
                creeLivre(); // Ajoute un livre
                break;
            case "2":
                supprimerlivre(); // Supprime un livre
                break;
            case "3":
                creeUtilisateur(); // Ajoute un utilisateur standard
                break;
            case "4":
                creeUtilisateurPremium(); // Ajoute un utilisateur premium
                break;
            case "5":
                supprimerUtilisateur(); // Supprime un utilisateur
                break;
            case "6":
                listerLivres(); // Liste tous les livres
                break;
            case "7":
                listerUtilisateurs(); // Liste tous les utilisateurs
                break;
            case "8":
                Console.WriteLine("Choisissez un utilisateur");
                listerUtilisateurs(); // Liste les utilisateurs pour en choisir un
                try
                {
                    int num = int.Parse(Console.ReadLine());
                    var utilisateur = listeUtilisateurs.OrderBy(util => util.Nom).ThenBy(util => util.Prenom).Skip(num).First();
                    menuUtilisateur(utilisateur); // Accède au menu pour cet utilisateur
                }
                catch
                {
                    throw new Exception("Entrez une valeur valide");
                }
                break;
            case "X":
                return; // Quitte l'application
            default:
                Console.WriteLine("Entrez une option valide");
                break;
        }
    }
    catch (Exception e)
    {
        Console.WriteLine(e.Message); // Affiche un
